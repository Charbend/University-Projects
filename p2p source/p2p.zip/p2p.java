package com.company;

import java.io.*;
import java.net.*;
import java.util.*;

public class p2p{

    public static void main(String[] args){
        Peer peer = new Peer();
        peer.runPeer();
    }

    public static class Peer {

        private boolean activeFlag = true; //True when peer is active
        private List<PeerSocketThread> neighbors = new ArrayList<PeerSocketThread>();
        private List<Integer> currentQueries = new ArrayList<Integer>();
        private List<Integer> myCurrentQueries = new ArrayList<Integer>();
        private Integer queryID;
        private int serverPortNum;
        private String ip;
        private ClientSocket clientSockOne;
        private ClientSocket clientSockTwo;

        public void runPeer() {
            try {
                setPersonalIdentifiers();
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
            ServerThread server = new ServerThread();
            System.out.println("Opening Server"); ////////Print
            server.start();

            Scanner userIn = new Scanner(System.in);
            System.out.println("Commands:\n1. Get <filename>\n2. Leave\n3. Connect\n4. Exit");

            //User input loop
            while (getActiveFlag() == true){
                System.out.println("Enter a command");
                String command = userIn.nextLine();

                String[] splitComm = command.split(" ");
                if (splitComm[0].equals("Get")){
                    System.out.println("Sending query"); //////////Print
                    getCurrentQueries().add(getQueryID()); //Add current query ID to list of current queries
                    getMyCurrentQueries().add(getQueryID());
                    getClientSockOne().printToServer("Q:"+(new Integer(getQueryID())).toString() +";" + splitComm[1]);
                    getClientSockTwo().printToServer("Q:"+(new Integer(getQueryID())).toString() +";" + splitComm[1]);
                    incrementQueryId();
                }
                else if (splitComm[0].equals("Leave")){
                    try {
                        if (getClientSockOne() != null)
                            getClientSockOne().close();
                        if (getClientSockTwo() != null)
                            getClientSockTwo().close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
                else if (splitComm[0].equals("Connect")){
                    try {
                        connect();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
                else if (splitComm[0].equals("Exit")){
                    try {
                        if (getClientSockOne() != null)
                            getClientSockOne().close();
                        if (getClientSockTwo() != null)
                            getClientSockTwo().close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    setActiveFlag(false);
                }
            }

            try {
                server.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            try {
                if (getClientSockOne() != null)
                    getClientSockOne().close();
                if (getClientSockTwo() != null)
                    getClientSockTwo().close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        } //End Peer.main()

        public void connect() throws IOException{
            BufferedReader connectReader = null;
            try {
                connectReader = new BufferedReader(new FileReader("config_neighbors.txt"));
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
            String sockOne = connectReader.readLine();
            if (sockOne == null)
                System.out.println("READ NULL LINE");
            String[] sockOneComp = sockOne.split(" ");
            System.out.println("Attempting to connect to peer"); ////////Print
            clientSockOne = new ClientSocket(InetAddress.getByName(sockOneComp[0]),Integer.parseInt(sockOneComp[1]));
            HeartBeatResponseThread hbrtOne = new HeartBeatResponseThread(getClientSockOne());
            hbrtOne.start();
            if (getClientSockOne().getPort() != 0)
                System.out.println("Successfully connected to peer" + getClientSockOne().getPort()); //////////Print

            String sockTwo = connectReader.readLine();
            String[] sockTwoComp = sockTwo.split(" ");
            System.out.println("Attempting to connect to peer"); ///////Print
            clientSockTwo = new ClientSocket(InetAddress.getByName(sockTwoComp[0]),Integer.parseInt(sockTwoComp[1]));
            HeartBeatResponseThread hbrtTwo = new HeartBeatResponseThread(getClientSockTwo());
            hbrtTwo.start();
            if (getClientSockTwo().getPort() != 0)
                System.out.println("Successfully connected to peer" + getClientSockTwo().getPort()); ///////Print
        }

        public void setPersonalIdentifiers() throws FileNotFoundException {
            BufferedReader configReader = new BufferedReader(new FileReader("config_peer.txt"));
            try { //Set IP
                setIp(configReader.readLine());
            } catch (IOException e) {
                e.printStackTrace();
            }

            try { //Set server port num
                setServerPortNum(Integer.parseInt(configReader.readLine()));
            } catch (IOException e) {
                e.printStackTrace();
            }

            queryID = Integer.parseInt((new Integer(getServerPortNum()).toString()) + "001");
        }

        /*************************************** GETTERS AND SETTERS  ***************************************************/
        public boolean getActiveFlag(){
            return activeFlag;
        }

        public void setActiveFlag(boolean newFlag){
            activeFlag = newFlag;
        }

        public List<PeerSocketThread> getNeighbors(){
            return neighbors;
        }

        public List<Integer> getCurrentQueries(){
            return currentQueries;
        }

        public List<Integer> getMyCurrentQueries(){
            return myCurrentQueries;
        }

        public String getIp(){
            return ip;
        }

        private void setIp(String newIP){
            ip = newIP;
        }

        public int getQueryID(){
            return queryID;
        }

        private void setQueryID(int id){
            queryID = id;
        }

        public void incrementQueryId(){
            queryID++;
        }

        public int getServerPortNum(){
            return serverPortNum;
        }

        private void setServerPortNum(int newPortNum){
            serverPortNum = newPortNum;
        }

        public ClientSocket getClientSockOne(){
            return clientSockOne;
        }

        public ClientSocket getClientSockTwo(){
            return clientSockTwo;
        }

        /***************************************  CLASSES  **************************************************************/

        public class ClientSocket extends Socket{

            private PrintWriter outToServer;

            public ClientSocket(InetAddress address, int port) throws IOException {
                super(address, port);
                outToServer = new PrintWriter(this.getOutputStream(),true);
            }

            public void printToServer(String message){
                System.out.println("Client Socket for " + getPort() + " got this message: " + message);
                outToServer.println(message);
            }
        }

        //Server thread to handle the server side
        public class ServerThread extends Thread{
            public void run(){
                //ACCEPTS BOTH NEIGHBOR CONNECTIONS AND FTP CONNECTIONS, BOTH GET TREATED THE SAME
                ServerSocket welcomeSocket = null;
                try {
                    welcomeSocket = new ServerSocket(getServerPortNum());
                } catch (IOException e) {
                    e.printStackTrace();
                }

                //Peer connection loop
                while (getActiveFlag()){
                    Socket connectionSocket = null;
                    try {
                        System.out.println("Accepting connection"); //////////Print
                        connectionSocket = welcomeSocket.accept();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    System.out.println("Peer connected"); /////////////Print
                    PeerSocketThread peerConnection = new PeerSocketThread(connectionSocket);
                    getNeighbors().add(peerConnection);
                    peerConnection.start();
                } //End while

                for (PeerSocketThread thread: getNeighbors()
                     ) {
                    try {
                        thread.join(); //End all threads
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        }

        //Thread class to manage peer connection sockets in their own threads
        public class PeerSocketThread extends Thread{

            //Variables
            private Socket connectionSock; //The socket that stores the connection to another peer
            private boolean activeConnectionFlag = true; //Flag determining if this connection is still open
            private BufferedReader inFromClient;

            //Constructor method
            public PeerSocketThread(Socket connectionSocket){
                connectionSock = connectionSocket;
            } //End PeerSocketThread constructor

            public void run(){
                //Establish input buffer for input stream, and establish output stream
                try {
                    inFromClient = new BufferedReader(new InputStreamReader(connectionSock.getInputStream()));
                } catch (IOException e) {
                    e.printStackTrace();
                }

                HeartBeatThread heartbeat = new HeartBeatThread(this);
                heartbeat.start();

                while(getActiveConnectionFlag()){
                    try {
                        String message = inFromClient.readLine();
                        //System.out.println("Server received: " + message); //////////////TEST
                        parseMessage(message); //inFromClient.readLine());
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }

                try {
                    inFromClient.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                try {
                    heartbeat.join();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            } //End PeerSocketThread.run()

            @Override
            public boolean equals(Object obj) {
                PeerSocketThread objPST = (PeerSocketThread) obj;
                if (getConnectionSock().equals(objPST.getConnectionSock()))
                    return true;
                else
                    return false;
            }

            /******************************************* PEERSOCKETTHREAD GETTERS AND SETTERS ****************************************/

            public boolean getActiveConnectionFlag(){
                return activeConnectionFlag;
            }

            public void setActiveConnectionFlag(boolean newFlag){
                activeConnectionFlag = newFlag;
            }

            public Socket getConnectionSock(){
                return connectionSock;
            }

            /****************************************** PEERSOCKETHREAD MESSAGES IN ****************************************************/

            //Takes an inbound message and parses it, determining the proper response
            public void parseMessage(String message) throws IOException{
                char code = message.charAt(0);
                String noHeaderMessage = message.substring(2);
                String[] messageComponents = noHeaderMessage.split(";");
                if (code == 'Q'){ //Query
                    System.out.println("Query received"); ///////////Print
                    boolean repeat = false;
                    int newQueryID = Integer.parseInt(messageComponents[0]);
                    //Handle repeat query (only accept queries for which there is no matching query Id)
                    for (Integer query: getCurrentQueries()
                         ) {
                        if (query.equals(newQueryID)) {
                            System.out.println("Query is a repeat"); /////////Print
                            repeat = true;
                        }
                    }
                    if (!repeat){ //Not a repeat query
                        System.out.println("Query is not a repeat"); /////////////Print
                        getCurrentQueries().add(newQueryID);
                        queryResponse(newQueryID,messageComponents[1]);
                    }
                }
                else if (code == 'R'){ //Response to a query
                    //Handle repeat response (Only accept responses for which there is a query with matching query Id)
                    System.out.println("Got a response: " + message); //////////TEST
                    int rQueryID = Integer.parseInt(messageComponents[0]);
                System.out.println("RQueryID: " + rQueryID); /////////////////////TEST
                    boolean repeat = true;
                    for (Integer query: getCurrentQueries()
                         ) {
                        System.out.println("query: "+ query); ///////////////////////TEST
                        if (query.equals(rQueryID))
                                repeat = false;
                    }
                    if (!repeat){
                        responseResponse(rQueryID,messageComponents[1],messageComponents[2]);
                    }
                }
                else if (code =='T') { //File transfer
                    //Connection established, just need to send file
                    System.out.println("Received file transfer request"); ////////////Print
                    BufferedReader readFile = new BufferedReader(new FileReader("shared/" + messageComponents[0]));
                    PrintWriter sendFile = new PrintWriter(getConnectionSock().getOutputStream());
                    String fileLine;
                    while ((fileLine = readFile.readLine()) != null){
                        sendFile.println(fileLine);
                    }
                    readFile.close();
                    sendFile.close();
                    System.out.println("File sent"); ///////////Print
                    getConnectionSock().close();
                }
                else if (code == 'H'){ //Heartbeat status check
                    if (messageComponents[0].equals("H")) {
                        System.out.println("Received heartbeat"); /////////Print
                        sendMessage("B");
                    }
                    else {
                        //System.out.println("Resetting Heartbeat"); //////////////TEST
                        setActiveConnectionFlag(true);
                    }
                }
            }

            //Respond to a query //queryID: ID of query//filename: name of file requested
            public void queryResponse(int queryID, String fileName) throws IOException{
                //Search for file, if found send Response, if not found, forward query
                BufferedReader fileFind = new BufferedReader(new FileReader("config_sharing.txt"));
                boolean found = false;
                String fileInTxt;

                while ((fileInTxt = fileFind.readLine()) != null){
                    if (fileInTxt.equals(fileName))
                            found = true;
                }
                if (found){
                    System.out.println("Have requested file"); //////////Print
                    sendMessage("R:" + (new Integer(queryID)).toString() + ";" + getIp() + ":" + getServerPortNum() + ";" + fileName);
                    System.out.println("Sent Response"); ////////////TEST
                }
                else {
                    System.out.println("Do not have requested file"); ///////////Print
                    sendMessageOtherConnection("Q:" + (new Integer(queryID)).toString() + ";" + fileName);
                    System.out.println("Forwarded Query"); ///////////////////TEST
                }
            }

            //respond to a response //queryID: ID of query//PeerIP and port of host with desired file//filename: name of file
            public void responseResponse(int queryID, String address, String filename){
                //If it is a response to one of my queries, send a FTP request, if not, forward response over other Client connection
                System.out.println("In ResponseResponse"); //////////////////TEST
                boolean myQuery = false;
                for (Integer queryIDind: getMyCurrentQueries()
                     ) {
                    if (queryIDind.equals(queryID))
                            myQuery = true;
                }
                if (myQuery){
                    //remove query from active lists
                    //establish connection
                    //Send T file
                    for (int i = 0; i < getMyCurrentQueries().size(); i++){
                        if (getMyCurrentQueries().get(i) == queryID)
                            getMyCurrentQueries().remove(i);
                    }
                    for (int i = 0; i < getCurrentQueries().size(); i++){
                        if (getCurrentQueries().get(i).equals(queryID))
                            getCurrentQueries().remove(i);
                    }

                    try {
                        sendFTP(address, filename);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }

            public void sendFTP(String address, String filename) throws UnknownHostException, IOException{
                System.out.print("Requesting file transfer"); ///////////Print
                String[] addressComp = address.split(":");
                ClientSocket FTP = new ClientSocket(InetAddress.getByName(addressComp[0]), Integer.parseInt(addressComp[1]));
                BufferedReader fromServer = new BufferedReader(new InputStreamReader(FTP.getInputStream()));
                BufferedWriter saveText = new BufferedWriter(new FileWriter("obtained/" + filename));
                FTP.printToServer("T:" + filename);
                String txtLine;
                while((txtLine = fromServer.readLine()) != null){
                    saveText.write(txtLine);
                }
                System.out.println("File received"); /////////Print
                FTP.close();
                fromServer.close();
                saveText.close();
            }

            public void sendHeartbeat(){
                //System.out.println("Sending heartbeat"); ///////////Print
                sendMessage("H:H");
            }


            public void sendMessage(String message){
               // System.out.println("Attemptimg to send message"); ///////////////////////////TEST
                //System.out.println("ClientSockOne " + getClientSockOne()); ///////////////TEST
               // System.out.println("ClientSockTwo" + getClientSockTwo()); /////////////TEST
                PrintWriter connSockP = null;
                try {
                    connSockP = new PrintWriter(getConnectionSock().getOutputStream(), true);
                } catch (IOException e) {
                    e.printStackTrace();
                }
                connSockP.println(message);
            }

            public void sendMessageOtherConnection(String message){
              //  System.out.println("Attemptimg to send message"); ///////////////////////////TEST
                for (PeerSocketThread neighbor: getNeighbors()
                     ) {
                    if (!neighbor.getConnectionSock().equals(getConnectionSock())){
                        neighbor.sendMessage(message);
                }
                }
            }
        } //End PeerSocketThread

        /*
        Class for use in PeerSocketThread to deal with sending periodic heartbeat messages
         */
        public class HeartBeatThread extends Thread{
            private PeerSocketThread pst;

            public HeartBeatThread(PeerSocketThread psThread){
                pst = psThread;
            }

            public void run(){
                while (pst.getActiveConnectionFlag()){
                        pst.setActiveConnectionFlag(false);
                        pst.sendHeartbeat();
                        try {
                            Thread.sleep(10000); //Sleep for 10 seconds
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }
                System.out.println("Closing connection from heartbeat timeout"); ///////////Print
            }
        }

        public class HeartBeatResponseThread extends Thread{
            private ClientSocket sock;

            public HeartBeatResponseThread(ClientSocket cSock){
                sock = cSock;
            }

            public void run(){
                //System.out.println("Running hbrt"); /////////////////TEST
                BufferedReader inFromServ = null;
                try {
                    inFromServ = new BufferedReader(new InputStreamReader(sock.getInputStream()));
                } catch (IOException e) {
                    e.printStackTrace();
                }
                PrintWriter outToServ = null;
                try {
                    outToServ = new PrintWriter(sock.getOutputStream(), true);
                } catch (IOException e) {
                    e.printStackTrace();
                }
                String in = "";

                while (true){
                    try {
                        //System.out.println("Trying to read");/////////////TEST
                        in = inFromServ.readLine();
                       // System.out.println("Client received: " + in); /////////////TEST
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    if (in != null)
                        if (in.equals("H:H"))
                            outToServ.println("H:B");
                        else{
                            for (PeerSocketThread neighbor: getNeighbors()
                                 ) {
                                try {
                                    neighbor.parseMessage(in);
                                } catch (IOException e) {
                                    e.printStackTrace();
                                }
                            }
                        }
                }
            }
        }
    } //End Peer
}
